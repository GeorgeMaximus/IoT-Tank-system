//#define mySSID "BTHub6-2X2J" // the username of the wifi or the SSID
//#define myPASSWORD "Wx6npVXqGwQT" // the username of the wifi
#define mySSID "DBHome" // the username of the wifi or the SSID
#define myPASSWORD "DB16091963" // the username of the wifi
